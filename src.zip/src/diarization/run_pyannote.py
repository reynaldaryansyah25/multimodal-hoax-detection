from pyannote.audio import Pipeline
from pathlib import Path
import torch
import time

HF_TOKEN = "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"

AUDIO_DIR = Path("data/processed")
OUTPUT_DIR = Path("data/diarization")
OUTPUT_DIR.mkdir(exist_ok=True, parents=True)

# Cek GPU availability
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Menggunakan device: {device}")

# Load pipeline dengan GPU jika tersedia
pipeline = Pipeline.from_pretrained(
    "pyannote/speaker-diarization-3.1", 
    use_auth_token=HF_TOKEN
)
pipeline.to(device)

# Ambil list files dan filter yang belum diproses
files = list(AUDIO_DIR.glob("*.wav"))
print(f"Total file ditemukan: {len(files)}")

for idx, audio_file in enumerate(files, 1):
    output_path = OUTPUT_DIR / f"{audio_file.stem}.rttm"
    
    # Skip jika sudah diproses
    if output_path.exists():
        print(f"[{idx}/{len(files)}] SKIP (sudah diproses): {audio_file.name}")
        continue
    
    print(f"\n[{idx}/{len(files)}] Memproses: {audio_file.name}")
    start_time = time.time()
    
    try:
        # Proses diarization dengan timeout handling
        diarization = pipeline(str(audio_file))
        
        # Simpan hasil
        with open(output_path, "w") as f:
            diarization.write_rttm(f)
        
        elapsed = time.time() - start_time
        print(f"✓ Selesai dalam {elapsed:.2f} detik")
        print(f"  Hasil disimpan: {output_path}")
        
    except Exception as e:
        print(f"✗ ERROR pada {audio_file.name}: {str(e)}")
        continue

print("\n=== SELESAI ===")
print(f"Total file diproses: {len(files)}")
